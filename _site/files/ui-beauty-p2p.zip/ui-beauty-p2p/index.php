<?php
include "secrets.php";
include "templating.php";
include "db.php";
include "cookie.php";
include "login.php";

$alerts = [];
$user = NULL;
if (isset($_COOKIE["login"])) {
	$user = verify_cookie($_COOKIE["login"]);
	if ($user === false) {
		setcookie("login", "", time() - 24 * 3600, "/", "", false, true);
		$user = NULL;
	}
} else if (isset($_GET["login"])
	&& isset($_POST["f-email"])
	&& isset($_POST["f-pass"])) {
	$user = verify_login($_POST["f-email"], $_POST["f-pass"]);
	if ($user === false) {
		$user = NULL;
		$alerts[] = ["Login failed. Please try again.", false];
	} else {
		setcookie("login", encode_cookie($user), time() + 3600, "/", "", false, true);
		$alerts[] = ["Successfully logged in!", true];
	}
} else if (isset($_GET["register"])
	&& isset($_POST["f-email"])
	&& isset($_POST["f-email-rep"])
	&& isset($_POST["f-pass"])
	&& isset($_POST["f-pass-rep"])) {
	if ($_POST["f-email"] == $_POST["f-email-rep"]
		&& $_POST["f-pass"] == $_POST["f-pass-rep"]
		&& verify_register($_POST["f-email"], $_POST["f-pass"])) {
		$alerts[] = ["Successfully registered! You may now log in.", true];
	} else {
		$alerts[] = ["Registration failed. Please try again.", false];
	}
}
if (isset($_GET["logout"]) && $user !== NULL) {
	$alerts[] = ["Logged out.", true];
	setcookie("login", "", time() - 24 * 3600, "/", "", false, true);
	$user = NULL;
}

$any = false;
foreach ([[
	"login" => [["#", "Login"], ["?register", "Register"]],
	"register" => [["?login", "Login"], ["#", "Register"]]
], [
	"tools" => [["?logout", "Logout"]],
	"tools-picker" => [["?tools", "Tools"], ["?logout", "Logout"]],
	"tools-graphs" => [["?tools", "Tools"], ["?logout", "Logout"]],
	"tools-flagship" => [["?tools", "Tools"], ["?logout", "Logout"]]
]][$user === NULL ? 0 : 1] as $page => $menu) {
	if (isset($_GET[$page])) {
		template_top(false);
		template_nav($menu);
		template_content($page);
		$any = true;
		break;
	}
}
if (!$any) {
	template_top(true);
	template_nav([
		["#front", "Home"],
		["#design", "Design"],
		["#synergy", "Synergy"],
		["#mavericks", "Mavericks"]
	], [
		[$user === NULL ? "?login" : "?tools", "Customer zone"]
	]);
	template_content("front");
}
template_footer();

?>