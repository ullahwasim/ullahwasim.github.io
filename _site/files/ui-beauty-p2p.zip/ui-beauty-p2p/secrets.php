<?php
$secret_flag = "BountyCon{this-is-not-the-flag}";
$secret_cookie_key = "better make this long and strong";
$secret_db = [
	"host" => "localhost",
	"user" => "root",
	"pass" => "root",
	"db" => "db"
];
?>