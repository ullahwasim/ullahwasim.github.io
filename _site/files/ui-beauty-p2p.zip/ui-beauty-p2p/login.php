<?php
if (!isset($secret_db))
	die("Forbidden");

function verify_login($email, $pass) {
	return fetch("select `email`, `role` from `users` where `email` = ? and `pass` = ?", [
		"ss", $email, $pass
	], ["email", "role"]);
}

function verify_register($email, $pass) {
	if (verify_login($email, $pass) !== false)
		return false;
	if (preg_match("/^[\.a-zA-Z0-9_-]+@([a-zA-Z0-9_-]+\.)+[a-zA-Z]+$/", $email) !== 1)
		return false;
	return execute("insert into `users` (`email`, `pass`, `role`) values (?, ?, \"user\")", [
		"ss", $email, $pass
	])->error === "";
}
?>