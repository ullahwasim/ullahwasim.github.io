<?php
if (!isset($secret_db))
	die("Forbidden");

function template_top($spy) {
	global $alerts;
	?><!DOCTYPE html><html><head>
	<title>UI toolkit</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
</head><body class="bg-secondary<?=(count($alerts) > 0 ? " pt-5" : "");?>"<?php
	if ($spy) {
		?> data-spy="scroll" data-target="#main-navbar" data-offset="0" class="bg-secondary"><?php
	} else {
		?>><?php
	}
}

function template_nav($items, $items2 = false) {
	?><nav id="main-navbar" class="navbar fixed-top text-light">
		<a class="navbar-brand" href="?">ui.beauty</a>
		<ul class="nav nav-pills"><?php
	foreach ($items as $item) {
			?>
			<li class="nav-item"><a class="nav-link" href="<?=$item[0];?>"><?=$item[1];?></a></li><?php
	}
	?>
		</ul><?php
	if ($items2 !== false) {
		foreach ($items2 as $item) {
			?>
		<a class="btn btn-outline-success" href="<?=$item[0];?>"><?=$item[1];?></a><?php
		}
	}
	?>
	</nav><?php
}

function template_content($page) {
	global $alerts, $secret_flag, $user;
	if (count($alerts) > 0) {
		?>
<div class="container-lg mt-3"><?php
		foreach ($alerts as $alert) {
			?>
	<div class="alert alert-<?=($alert[1] ? "success" : "danger");?>" role="alert"><?=$alert[0];?></div><?php
		}
		?>
</div><?php
	}
	include "pages/" . $page . ".php";
}

function template_footer() {
	?>
<footer class="footer mt-5 py-5 bg-light">
	<div class="container">
		<div class="row">
			<div class="col-sm-3">
				<p class="lead">To say of what is that it is not, or of what is not that it is, is false, while to say of what is that it is, and of what is not that it is not, is true.</p>
				<small>A R I S T O T L E</small>
			</div>
			<div class="col-sm-3">
				<h3>Stay in touch</h3>
				<a href="mailto:hello@ui.beauty" class="contact-link">hello@ui.beauty</a><br>
				<a href="tel:123456789" class="contact-link">(123) 456-789</a>
			</div>
			<div class="col-sm-3">
				<h3>Come visit</h3>
				<em>ui.beauty</em><br>
				123 Neverending Street<br>
				Unicorn Hills<br>
				<br>
				55555 Minneadelphia
			</div>
			<div class="col-sm-3">
				© 2019 The ui.beauty company
			</div>
		</div>
	</div>
</footer>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body></html><?php
}

?>