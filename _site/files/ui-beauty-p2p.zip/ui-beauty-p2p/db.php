<?php
if (!isset($secret_db))
	die("Forbidden");

$db = new mysqli($secret_db["host"], $secret_db["user"], $secret_db["pass"], $secret_db["db"]);

if (!$db || $db->connect_errno)
	die("Failed to connect to database");

function execute($query, $params) {
	global $db;
	$stmt = $db->prepare($query);
	if (!$stmt)
		die("Failed to prepare statement");
	$refs = [];
	foreach ($params as $key => $value) {
		$refs[$key] = &$params[$key];
	}
	call_user_func_array(array($stmt, "bind_param"), $refs);
	if (!$stmt->execute())
		die("MySQL error: " . $stmt->error);
	return $stmt;
}

function fetchAll($query, $params, $cols, $limit = -1) {
	$stmt = execute($query, $params);
	$vars = [];
	$data = [];
	foreach ($cols as $col) {
		$vars[] = &$data[$col];
	}
	call_user_func_array(array($stmt, "bind_result"), $vars);
	$rows = 0;
	$res = [];
	while ($stmt->fetch()) {
		$row = [];
		foreach ($data as $key => $val) {
			$row[$key] = $val;
		}
		$res[] = $row;
		$rows++;
		if ($limit !== -1 && $rows >= $limit)
			break;
	}
	return $res;
}

function fetch($query, $params, $cols) {
	$res = fetchAll($query, $params, $cols, 1);
	if (count($res) === 0)
		return false;
	return $res[0];
}
?>