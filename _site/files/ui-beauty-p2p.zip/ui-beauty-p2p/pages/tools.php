<div class="container-lg text-light pt-5 mt-5">
	<div class="row">
		<div class="col-sm-3">
			<h3>Colour picker</h3>
			<p>Our designers are positively <em>vibing</em> when using this product. It represents the future, the smooth gradients of a neo-noir cyber-punk post-statementist sky. Palettes and colours aplenty. Shay-dee!</p>
			<a class="btn btn-primary" href="?tools-picker">Try it!</a>
		</div>
		<div class="col-sm-3">
			<h3>Graphs</h3>
			<p>Data is the key to acquisition, acquisition is the key to business, and business is the lock opened only by the few that know how to play the game. Don't be a player, <em>change</em> the <b>rules</b>. The rules are there to form an exception, if you know the secret key. Data.</p>
			<a class="btn btn-primary" href="?tools-graphs">Try it!</a>
		</div>
		<div class="col-sm-3">
			<h3>ui.beauty P2P distribution</h3>
			<p>At our company we embrace the future. Mesh networks are a foundation in our vision. Join us in this formidable dream, host a ui.beauty instance on your own server!</p>
			<a class="btn btn-primary" href="ui-beauty-p2p.zip" download>Try it!</a>
		</div>
		<div class="col-sm-3">
			<h3>Secret FLAGship product</h3>
			<p>What could it be … ?!</p>
			<a class="btn btn-primary" href="?tools-flagship">Try it! (Admin only)</a>
		</div>
	</div>
</div>
