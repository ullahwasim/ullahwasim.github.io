<div class="container-lg text-light pt-5 mt-5">
	<h1>FLAGship product</h1>
	<?php
	if ($user["role"] === "admin") {
	?><p class="lead">Keep it to yourself.</p>
	<div class="display-4"><?=$secret_flag;?></div><?php
	} else {
	?><p>You're not ready.</p><?php
	}
	?>
</div>