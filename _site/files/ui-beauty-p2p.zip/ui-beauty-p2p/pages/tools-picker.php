<div class="container-lg text-light pt-5 mt-5">
	<h1>Pick these colours!</h1>
	<p class="lead">These colours are hand-picked by our coloursmiths. They are guaranteed to work for any aesthetic whatsoever.</p>
	<div class="row">
		<div class="col-sm-3">
			<h3>Red</h3>
			<small>#ff0000</small>
			<div class="card" style="background:#ff0000;">&nbsp;</div>
		</div>
		<div class="col-sm-3">
			<h3>Darkish purplish-red</h3>
			<small>#cc0066</small>
			<div class="card" style="background:#cc0066;">&nbsp;</div>
		</div>
		<div class="col-sm-3">
			<h3>Gray</h3>
			<small>#6c757d</small>
		</div>
		<div class="col-sm-3">
			<h3>Nougat</h3>
			<small>#7c3a2b</small>
			<div class="card" style="background:#7c3a2b;">&nbsp;</div>
		</div>
		<div class="col-sm-3">
			<h3 class="mt-3">White (almost)</h3>
			<small>#fbfbfb</small>
			<div class="card" style="background:#fbfbfb;">&nbsp;</div>
		</div>
		<div class="col-sm-3">
			<h3 class="mt-3">Jet black</h3>
			<small>#002233</small>
			<div class="card" style="background:#002233;">&nbsp;</div>
		</div>
		<div class="col-sm-3">
			<h3 class="mt-3">Hazelnut</h3>
			<small>#7c3a2c</small>
			<div class="card" style="background:#7c3a2c;">&nbsp;</div>
		</div>
		<div class="col-sm-3">
			<h3 class="mt-3">Purplish dark red</h3>
			<small>#cc0066</small>
			<div class="card" style="background:#cc0066;">&nbsp;</div>
		</div>
	</div>
</div>
