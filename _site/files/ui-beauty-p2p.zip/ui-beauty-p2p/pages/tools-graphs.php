<div class="container-lg text-light pt-5 mt-5">
	<h1>Data</h1>
	<p class="lead">Sorted by acquisition.</p>
	<small>Source: Surveys-R-Us National Survey 2020.</small>
	<img src="res/data.png" class="d-block w-100 mt-5">
</div>