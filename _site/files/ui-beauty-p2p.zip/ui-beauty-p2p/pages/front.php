<div id="front" class="carousel slide" data-ride="carousel">
	<ol class="carousel-indicators">
		<li data-target="#front" data-slide-to="0" class="active"></li>
		<li data-target="#front" data-slide-to="1"></li>
		<li data-target="#front" data-slide-to="2"></li>
	</ol>
	<div class="carousel-inner">
		<div class="carousel-item active">
			<div class="carousel-image carousel-image-1"></div>
			<div class="carousel-caption d-none d-md-block">
				<h5>Professional UI</h5>
				<p>Good UI is not a choice. It is a lifestyle. A lifestyle we offer.<br>
					This offer is not something you can just buy. It is a choice.</p>
			</div>
		</div>
		<div class="carousel-item">
			<div class="carousel-image carousel-image-2"></div>
			<div class="carousel-caption d-none d-md-block">
				<h5>Company-oriented design</h5>
				<p>Let's face it – most companies don't care about design.<br>
					We're not a company. We care about design.</p>
			</div>
		</div>
		<div class="carousel-item">
			<div class="carousel-image carousel-image-3"></div>
			<div class="carousel-caption d-none d-md-block">
				<h5>Synergistic thinking</h5>
				<p>Can you recall the last time you heard the word "troglodytine"?<br>
					Now. Next time you hear it, you will think of us, and our UI.</p>
			</div>
		</div>
	</div>
	<a class="carousel-control-prev" href="#front" role="button" data-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	</a>
	<a class="carousel-control-next" href="#front" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	</a>
</div>

<div class="container-lg text-light">

	<h1 id="design" class="mt-5">Design</h1>
	<div class="float-lg-right">
		<blockquote class="blockquote pl-3">
			<p>ui.beauty helped me make the most out of my website.</p>
			<footer class="blockquote-footer text-light">a satisfied customer</footer>
		</blockquote>
	</div>
	<p class="lead">Our team of artisanal designers are ready to refuel your brand, energise your workflow, and prioritise your syndication. We picked the best out of the best of our friends to joing our company.</p>
	<p>We are:</p>
	<ul>
		<li>Skilled</li>
		<li>Lean</li>
		<li>Employable</li>
		<li>Unchained</li>
	</ul>

	<img src="res/cat4.jpg" class="d-block w-100" alt="">

	<h1 id="synergy" class="mt-5">Synergy</h1>
	<p class="lead">Why settle for the second best when you could have ui.beauty instead? From our choice of domain to our masterfully-crafted bootstrap CSS, you can tell we're the best. We even speak Latin!</p>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	<p>But don't take our word for it. See for yourself!</p>

	<img src="res/cat5.jpg" class="d-block w-100" alt="">

	<h1 id="mavericks" class="mt-5">Mavericks</h1>
	<p class="lead">Notice how the previous cat image is upside down? We are not afraid to play the game of mind tricks. We are architects of the mind, mavericks of the corporation, jesters of the court of symmetry.</p>
	<p>And we play the game to win.</p>

</div>