<div class="container-lg text-light pt-5">

	<h1 class="mt-5">Login</h1>

	<div class="float-lg-right">
		<blockquote class="blockquote pl-3">
			<p>ui.beauty helped me make the most out of my website.</p>
			<footer class="blockquote-footer text-light">a satisfied customer</footer>
		</blockquote>
	</div>

	<p class="lead">Our team of artisanal designers are ready to refuel your brand, energise your workflow, and prioritise your syndication. We picked the best out of the best of our friends to joing our company.</p>

</div><div class="jumbotron bg-light mt-5">

<form action="?login" method="post">
	<div class="form-group">
		<label for="f-email">E-mail address</label>
		<input type="email" class="form-control" id="f-email" name="f-email" aria-describedby="emailHelp">
		<small id="emailHelp" class="form-text text-muted">We'll only share your email with advertising companies and our sponsors. Nobody else, we promise, because privacy matters to us.</small>
	</div>
	<div class="form-group">
		<label for="f-pass">Password</label>
		<input type="password" class="form-control" id="f-pass" name="f-pass">
		<small id="emailHelp" class="form-text text-muted">We'll keep your password really safe! Our employees are trained to close (or at least significantly squint) their eyes when looking at the database data.</small>
	</div>
	<button type="submit" class="btn btn-primary">Login</button>
</form>

</div>
