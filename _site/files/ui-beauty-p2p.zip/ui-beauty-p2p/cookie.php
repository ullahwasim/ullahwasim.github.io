<?php
if (!isset($secret_db))
	die("Forbidden");

function verify_cookie($cookie) {
	global $secret_cookie_key;
	$cd = base64_decode(strrev($cookie));
	if (strlen($cd) <= 32)
		return false;
	$data = substr($cd, 0, -32);
	$hash = substr($cd, -32);
	$rhash = md5($secret_cookie_key . $data);
	if ($rhash !== $hash)
		return false;
	$user = fetch("select `email`, `role` from `users` where `email` = \"" . $data . "\"", [], ["email", "role"]);
	if ($user === false)
		return false;
	return $user;
}

function encode_cookie($user) {
	global $secret_cookie_key;
	return strrev(base64_encode($user["email"] . md5($secret_cookie_key . $user["email"])));
}
?>